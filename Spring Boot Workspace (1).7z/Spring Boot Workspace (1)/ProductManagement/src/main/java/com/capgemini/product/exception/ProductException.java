package com.capgemini.product.exception;

public class ProductException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProductException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
