package com.capgemini.product.service;

import java.util.List;

import com.capgemini.product.dto.Product;
import com.capgemini.product.exception.ProductException;

public interface ProductService {

	Product addProduct(Product product) throws ProductException;
	
	Product updateProduct(int id,Product product)throws ProductException;
	
	List<Product> getAllProduct() throws ProductException;
	
	List<Product> deleteProduct(int id)throws ProductException;
	
	Product getProductById(int id)throws ProductException;
	
	List<Product> getProductByCategory(String catName)throws ProductException;
	
	List<Product> getProductByPrice(double value)throws ProductException;
	
}
