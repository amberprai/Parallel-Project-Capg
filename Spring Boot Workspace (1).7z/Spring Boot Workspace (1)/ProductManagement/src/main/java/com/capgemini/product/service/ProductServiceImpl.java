package com.capgemini.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.product.dao.ProductRepository;
import com.capgemini.product.dto.Product;
import com.capgemini.product.exception.ProductException;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	private ProductRepository productDao;

	@Override
	public Product addProduct(Product product) throws ProductException {
		productDao.save(product);
		return product;
	}

	@Override
	public Product updateProduct(int id,Product product) throws ProductException {
		if(productDao.existsById(id)) {
			Product product1=productDao.findById(id).get();
			product1.setPrice(product.getPrice());
			product1.setQuantity(product.getQuantity());
			productDao.save(product1);
			return product1;
		}else {
			throw new ProductException("Product with id "+id+" doesn't exist");
		}
	}

	@Override
	public List<Product> getAllProduct() throws ProductException {
		
		return productDao.findAll();
	}

	@Override
	public List<Product> deleteProduct(int id) throws ProductException {
			if(productDao.existsById(id)) {
				productDao.deleteById(id);
				return getAllProduct();
			}else {
				throw new ProductException("Product with id "+id+" doesn't exist");
			}
			
	}

	@Override
	public Product getProductById(int id) throws ProductException {
			Optional<Product> product=productDao.findById(id);
			if(product.isPresent()) {
				return product.get();
			}else {
				throw new ProductException("Product with id "+id+" doesn't exist" );
			}
	}

	@Override
	public List<Product> getProductByCategory(String catName) throws ProductException {
		return productDao.getProductsByCategory(catName);
		
	}

	@Override
	public List<Product> getProductByPrice(double value) throws ProductException {
		return productDao.getProductByPrice(value);
	}

	
}
