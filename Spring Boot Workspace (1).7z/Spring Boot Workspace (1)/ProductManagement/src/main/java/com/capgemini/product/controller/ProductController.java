package com.capgemini.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.product.dto.Product;
import com.capgemini.product.exception.ProductException;
import com.capgemini.product.service.ProductService;

/**
 * 
 * @author Harshit Kumar
 * Date: 22-08-2019
 * ClassName: ProductController
 * Description: It handles the restful request
 *
 */
@RestController
@RequestMapping("/api")
public class ProductController {

	@Autowired
	private ProductService productService;
	
	@PostMapping("/products")
	public Product insertProduct(@RequestBody Product product) throws ProductException {
		return productService.addProduct(product);
	}
	
	@PutMapping("/products/{id}")
	public Product updateEmployee(@PathVariable int id,@RequestBody Product product) throws ProductException {
		return productService.updateProduct(id, product);
	}
	
	@GetMapping("/products")
	public List<Product> retrieveAllProducts() throws ProductException{
		return productService.getAllProduct();
	}
	
	@DeleteMapping("/product/{id}")
	public List<Product> deleteProductById(@PathVariable int id)throws ProductException{
		return productService.deleteProduct(id);
	}
	
	@GetMapping("/product/{id}")
	public Product retrieveProductById(@PathVariable int id)throws ProductException{
		return productService.getProductById(id);
	}
	
	@GetMapping("products/category")
	public List<Product> retrieveProductByCategory(@RequestParam String catName)throws ProductException{
		return productService.getProductByCategory(catName);
	}
	
	@GetMapping("products/price")
	public List<Product> retrieveProductByPrice(@RequestParam double value)throws ProductException{
		return productService.getProductByPrice(value);
	}
}
