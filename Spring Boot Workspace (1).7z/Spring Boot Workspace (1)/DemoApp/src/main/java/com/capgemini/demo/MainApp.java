package com.capgemini.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MainApp {

	public static void main(String[] args) {
		
		//This will make the application to run
		SpringApplication.run(MainApp.class, args);

	}

}
