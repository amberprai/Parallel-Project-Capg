package com.capgemini.employee.service;

import java.util.List;

import com.capgemini.employee.dto.Employee;
import com.capgemini.employee.exception.EmployeeException;


public interface EmployeeService {

	List<Employee> getAllEmployees() throws EmployeeException;
	
	Employee getEmployeeById(int id)throws EmployeeException;
	
	List<Employee> addEmployee(Employee employee)throws EmployeeException;
	
	List<Employee> deleteEmployee(int id)throws EmployeeException;
	
	List<Employee> updateEmployee(int id,Employee employee)throws EmployeeException;
	
	List<Employee> getEmployeeByDepartment(String deptName) throws EmployeeException;
 }
