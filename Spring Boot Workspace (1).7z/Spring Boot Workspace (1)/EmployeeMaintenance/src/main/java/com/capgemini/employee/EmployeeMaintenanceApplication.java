package com.capgemini.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeMaintenanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeMaintenanceApplication.class, args);
	}

}
