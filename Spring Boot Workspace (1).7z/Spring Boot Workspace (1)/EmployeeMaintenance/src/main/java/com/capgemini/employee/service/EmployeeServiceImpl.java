package com.capgemini.employee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.employee.dao.EmployeeRepository;
import com.capgemini.employee.dto.Employee;
import com.capgemini.employee.exception.EmployeeException;
/**
 * 
 * @author Harshit Kumar
 * Date of Creation: 21-08-2019
 * Class Employee Service Implementation
 * Description:
 *
 */
@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeRepository employeeDao;
	/**
	 * Author: Harshit Kumar
	 * Date: 21-08-2019
	 * Method Name: getAllEmployee()
	 * Parameters: Nil
	 * Purpose: To Retrieve all employee from the database
	 */
	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
				try {
					return employeeDao.findAll();
				} catch (Exception e) {
					throw new EmployeeException(e.getMessage());
				}
	}

	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
		
		try {
			Optional<Employee> data= employeeDao.findById(id);
			if(data.isPresent()) {
				return data.get();
			}else {
				throw new EmployeeException("Employee with Id "+id+" does not exist");
			}
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}

	@Override
	public List<Employee> addEmployee(Employee employee) throws EmployeeException {
		try {
			if(employee.getAge()>55) {
				throw new EmployeeException("Age cannot exceed 55");
			}
			if(employee.getDepartment().equals("IT") || employee.getDepartment().equals("Sales") || employee.getDepartment().equals("HR")) {
				employeeDao.save(employee);
				return getAllEmployees();
			}else {
				throw new EmployeeException("Department should be either IT, Sales or HR");
			}
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}

	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
		
		if(employeeDao.existsById(id)) {
			employeeDao.deleteById(id);
			return getAllEmployees();
		}else {
			throw new EmployeeException("Cannot Delete Employee with Id "+id+" doesn't exist");
		}
	}

	@Override
	public List<Employee> updateEmployee(int id,Employee employee) throws EmployeeException {
		
		if(employeeDao.existsById(id)) {
			employeeDao.save(employee);
			return getAllEmployees();
		}else {
			throw new EmployeeException("Invalid Employee, Cannot be upated");
		}
	}

	@Override
	public List<Employee> getEmployeeByDepartment(String deptName) throws EmployeeException {
		
		return employeeDao.getEmployeeByDepartment(deptName);
	}

}
