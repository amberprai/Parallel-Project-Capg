package com.capgemini.course.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.course.dto.Course;
import com.capgemini.course.exception.CourseException;
import com.capgemini.course.service.CourseService;

@RestController
@RequestMapping("App")
public class CourseController {

	@Autowired
	private CourseService courseService;
	
	@PostMapping("/course")
	public Course addCourseDetails(@RequestBody Course course) throws CourseException {
		return courseService.addCourse(course);
		
	}
	
	@PutMapping("/course/{id}")
	public Course updateCourseDetails(@RequestBody Course course,@PathVariable String id) throws CourseException {
		return courseService.updateCourse(course, id);
	}
	
	@GetMapping("/courses")
	public List<Course> getCourseDetails()throws CourseException{
		return courseService.getAllCourses();
	}
	
	@DeleteMapping("/course/{id}")
	public List<Course> deleteCourseDetails(@PathVariable String id) throws CourseException{
		return courseService.deleteCourse(id);
	}
	
	@GetMapping("/course/{id}")
	public Course getCourseDetailsById(@PathVariable String id)throws CourseException{
		return courseService.getCourseById(id);
	}
	
	@GetMapping("/course/mode")
	public List<Course> getCourseByMode(@RequestParam String mode)throws CourseException{
		return courseService.getCourseByMode(mode);
		
	}
}
