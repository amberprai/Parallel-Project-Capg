package com.capgemini.course.exception;

public class CourseException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CourseException() {
		super();
	
	}

	public CourseException(String message) {
		super(message);
		
	}

	
}
