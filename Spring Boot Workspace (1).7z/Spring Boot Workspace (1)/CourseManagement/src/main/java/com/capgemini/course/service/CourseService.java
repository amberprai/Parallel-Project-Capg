package com.capgemini.course.service;

import java.util.List;

import com.capgemini.course.dto.Course;
import com.capgemini.course.exception.CourseException;

public interface CourseService {

	public Course addCourse(Course course)throws CourseException;
	
	public Course updateCourse(Course course,String id)throws CourseException;
	
	public List<Course> getAllCourses() throws CourseException;
	
	public List<Course> deleteCourse(String id)throws CourseException;
	
	public Course getCourseById(String id)throws CourseException;
	
	public List<Course> getCourseByMode(String mode)throws CourseException;
}
