package com.capgemini.course.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.course.dao.CourseRepository;
import com.capgemini.course.dto.Course;
import com.capgemini.course.exception.CourseException;

/**
 * 
 * @author Harshit Kumar
 * Date: 22/08/2019
 * Class Name: CourseServiceImpl
 * Description: This gives the implementation of all the service methods
 *
 */
@Service
public class CourseServiceImpl implements CourseService{

	@Autowired
	private CourseRepository courseDao;
	
	@Override
	public Course addCourse(Course course) throws CourseException {
		try {
			courseDao.save(course);
			return course;
		} catch (Exception e) {
			throw new CourseException(e.getMessage());
		}
	}

	@Override
	public Course updateCourse(Course course,String id) throws CourseException {
		try {
			if(courseDao.existsById(id)) {
				Course course1=courseDao.findById(id).get();
				//.setCourseId(course.getCourseId());
				course1.setCourseName(course.getCourseName());
				course1.setDuration(course.getDuration());
				course1.setFaculty(course.getFaculty());
				course1.setMode(course.getMode());
				courseDao.save(course1);
				return course1;
			}else {
				throw new CourseException("Course with Id "+id+" doesn't exist");
			}
			
		} catch (Exception e) {
			throw new CourseException(e.getMessage());
		}
	}

	@Override
	public List<Course> getAllCourses() throws CourseException {
		
		try {
			return courseDao.findAll();
		} catch (Exception e) {
			throw new CourseException(e.getMessage());
		}
	}

	@Override
	public List<Course> deleteCourse(String id) throws CourseException {
		try {
			courseDao.deleteById(id);
			return getAllCourses();
		} catch (Exception e) {
			throw new CourseException(e.getMessage());
		}
	}

	@Override
	public Course getCourseById(String id) throws CourseException {
		
		try {
			Optional<Course> course= courseDao.findById(id);
			if(course.isPresent()) {
				 return course.get();
			}else {
				throw new CourseException("Id doesn't exist");
			}
		} catch (Exception e) {
			throw new CourseException(e.getMessage());
		}
		
	}

	@Override
	public List<Course> getCourseByMode(String mode) throws CourseException {
		try {
			return courseDao.getCourseByMode(mode);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CourseException(e.getMessage());
		}
	}
	
	

}
