package com.capgemini.course.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.course.dto.Course;
import com.capgemini.course.exception.CourseException;
@Repository
public interface CourseRepository extends JpaRepository<Course, String>{

	@Query("from Course where mode=:mode")
	public List<Course> getCourseByMode(@Param("mode") String mode)throws CourseException;
}