package com.capgemini.order.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.order.dto.Order;
import com.capgemini.order.exception.OrderException;
import com.capgemini.order.service.OrderService;

@RestController
@RequestMapping("/app")
public class OrderController {

	@Autowired
	private OrderService orderService;
	
	@PostMapping("/order")
	public List<Order> acceptOrder(@RequestBody Order order)throws OrderException{
		orderService.addOrder(order);
		return viewAllOrders();
		
	}
	
	@GetMapping("/orders")
	public List<Order> viewAllOrders()throws OrderException {
		return orderService.displayAllOrders();
	}
	
	
}
