package com.capgemini.order.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.order.dao.OrderRepository;
import com.capgemini.order.dto.Order;
import com.capgemini.order.exception.OrderException;

@Service
public class OrderServiceImpl implements OrderService{

	@Autowired
	private OrderRepository orderDao;
	
	private Order newOrder=new Order();

	@Override
	public List<Order> displayAllOrders() throws OrderException {
		
		return orderDao.findAll();
	}

	@Override
	public List<Order> addOrder(Order order) throws OrderException {
		double newPrice=currencyConverter(order.getPrice(),order.getQuantity());
		double conversionCharge=newPrice * 0.0125;
		double amount=newPrice * 0.0125+newPrice;
		double total=amount*order.getQuantity();
		
		order.setPrice(amount);
		order.setCharges(conversionCharge);
		order.setAmount(total);
		orderDao.save(order);
		return displayAllOrders();
	}

	public double currencyConverter(double price,int quantity) {
		double dollar=75;
		double priceInINR=price *dollar *quantity;
		return priceInINR;
		
	}
	
	
}
