package com.capgemini.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImportedOrderApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImportedOrderApplication.class, args);
	}

}
