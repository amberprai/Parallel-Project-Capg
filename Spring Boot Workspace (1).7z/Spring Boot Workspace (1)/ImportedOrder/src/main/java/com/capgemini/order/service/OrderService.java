package com.capgemini.order.service;

import java.util.List;

import com.capgemini.order.dto.Order;
import com.capgemini.order.exception.OrderException;

public interface OrderService {

	public List<Order> displayAllOrders()throws OrderException;

	List<Order> addOrder(Order order) throws OrderException;
	
	List<Order> updateOrder(int id)throws OrderException;
}
