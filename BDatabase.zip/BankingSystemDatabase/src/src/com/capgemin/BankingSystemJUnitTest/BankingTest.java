/*package com.capgemin.BankingSystemJUnitTest;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.capgemin.BankingSystem.Bean.Transactions;
import com.capgemini.BankingSystem.Dao.BankinSystemDao;

class BankingTest {
	BankinSystemDao dao=new BankinSystemDao();
	BankinSystemDao dao1=new BankinSystemDao();
	static Transactions trans=null;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		trans=new Transactions(0,1000,2000,LocalDate.now().toString(),"Credit");
		
		
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testgetAllTransactions() {
		
		assertNotNull(dao.getAllTransactions());
		assertNotSame(dao.getAllTransactions(), false);
		//assertSame(dao.getAllTransactions(), dao1.getAllTransactions());
	}
	@Test
	void testaddTransactions() {
		boolean result=dao.addTransaction(trans,121);
		boolean result2=dao.addTransaction(trans,122);
		assertTrue(result);
		assertEquals(result2, true);
		assertNotSame(result2, false);
		assertSame(result2,true);
        
	}
	

*/
