package src.com.capgemini.BankingSystem.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import src.com.capgemini.BankingSystem.Utility.DBConnection;
import src.com.capgemin.BankingSystem.Bean.Banking;
import src.com.capgemin.BankingSystem.Bean.Transactions;

public class BankinSystemDao implements IBankingSystemDao {
	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;
	int row = -1;
	int authorId = 0;
	static boolean status=false;
	List<Transactions> transList=null;
	
	@Override
	public void createTable(String accountNo)
	{
		try(Connection connection = DBConnection.getConnection();) {
			
			//String query="create table "+accountNo+" (TId number(10) primary key,"+"Amount Number(10), "+"Balance Number(10),"+"Transaction_Date varchar2(20),"+"Narration varchar2(25))";
			//System.out.println(query);
			statement=connection.prepareStatement("create table "+accountNo+" (TId number(10) primary key,"+"Amount Number(10), "+"Balance Number(10),"+"Transaction_Date varchar2(20),"+"Narration varchar2(25))");
			status=statement.execute();
			System.out.println("Transaction Sheet Opened");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Override
	public boolean insertToTransaction(Transactions tran, int transactId,String AccountNo) {
		try (Connection connection = DBConnection.getConnection();) {
			statement = connection.prepareStatement("insert into "+ AccountNo +" values (?,?,?,?,?)");
			System.out.println(tran.getTranscationId());
			statement.setInt(1, tran.getTranscationId());
			statement.setDouble(2, tran.getamount());
			statement.setDouble(3, tran.getBalance());
			statement.setString(4, tran.getDate());
			statement.setString(5, tran.getNarration());
			row = statement.executeUpdate();
			return true;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return false;
	}
	
	@Override
	public boolean insertIntoBanking(Banking banking)
	{ 
		try (Connection connection = DBConnection.getConnection();)
		{
		/*statement = connection.prepareStatement("select username from Banking where user=?");
		 statement.setString(1,user);
		 resultSet=statement.executeQuery();
		 while(resultSet.next())
		 {
			 if(resultSet.equals(user))
			 {
				System.out.println("User Already Exists");
					return false;
			 }
		 }*/
			statement = connection.prepareStatement("insert into Banking values(?,?,?,?,?,?,?)");			
			statement.setString(1,banking.getUsername());
			statement.setString(2,banking.getPassword());
			statement.setString(3,banking.getAadhaar());
			statement.setString(4, banking.getAccountNo());
			statement.setString(5,banking.getMobile());
			statement.setString(6,banking.getName());
			statement.setDouble(7,banking.getBalance());
			
			
			row = statement.executeUpdate();
			return true;
		} catch (SQLException e) {
			if(e.getMessage().contains("unique constraint")) { 
				System.err.println("Username already taken. Please choose different Username..!!"); } 
			return false;
		}
	}
	
	@Override
	public List<Transactions> getAllTransaction(String AccountNo)
	{       transList= new ArrayList<>();
		try (Connection connection = DBConnection.getConnection();) {
			statement = connection.prepareStatement("select * from "+AccountNo);
System.out.println("select * from "+AccountNo);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				Transactions trans = new Transactions();
				trans.setTranscationId(resultSet.getInt("TID"));
				trans.setamount(resultSet.getDouble("Amount"));
				trans.setBalance(resultSet.getDouble("Balance"));
				trans.setDate(resultSet.getString("Transaction_Date"));
				trans.setNarration(resultSet.getString("Narration"));
				transList.add(trans);
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return transList;		
	}

	@Override
	public Banking loginUser(String user, String pass) {
		try (Connection connection = DBConnection.getConnection();) {
			statement = connection.prepareStatement("select * from  Banking");
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
			if(resultSet.getString("Username").contentEquals(user) && resultSet.getString("Password").contentEquals(pass)) {
				Banking bank=new Banking();
				bank.setUsername(user);
				bank.setPassword(pass);
				bank.setAadhaar(resultSet.getString("Aadhaar"));
				bank.setAccountNo(resultSet.getString("AccountNO"));
				bank.setMobile(resultSet.getString("Mobile"));
				bank.setName(resultSet.getString("Name"));
				bank.setBalance(resultSet.getDouble("Balance"));
				return bank;
			}				
		}	
		
	} catch (SQLException e) {
		e.printStackTrace();
	}return null;
	

	}

	@Override
	public double balance(String accountNo) {
		try (Connection connection = DBConnection.getConnection();) {
			statement = connection.prepareStatement("select  balance from  Banking where AccountNO ='"+accountNo+"'");
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
			return resultSet.getDouble("Balance");
			}				
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return 0;
	}

	@Override
	public void updateBalance(double balance, String accountNo) {
		try (Connection connection = DBConnection.getConnection();) {
			statement = connection.prepareStatement("update Banking  set balance= "+balance+"where AccountNO ='"+accountNo+"'");
			resultSet = statement.executeQuery();	
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}
	
	
/*	@Override
	public double getBalance(String accoutNo)
	{

		try (Connection connection = DBConnection.getConnection();) {
			statement = connection.prepareStatement("select balance from"+AccountNo+" ");
			resultSet = statement.executeQuery();
			while (resultSet.next())
			if (resultSet.next()) {
				Transactions trans = new Transactions();
				trans.setTranscationId(resultSet.getInt("TID"));
				trans.setamount(resultSet.getDouble("Amount"));
				trans.setBalance(resultSet.getDouble("Balance"));
				trans.setDate(resultSet.getString("Date"));
				trans.setNarration(resultSet.getString("Narration"));
				transList.add(trans);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return transList;	
	}
	
	
	*/	
	
	
	/*BankingRepository br=new BankingRepository();
	Map<Integer, Transactions> transactionsMap = new LinkedHashMap<Integer, Transactions>();
	public BankinSystemDao() {
		transactionsMap.putAll(br.getTransList());
	}
	
	
	int id=0;
	
	@Override
	public Map<Integer, Transactions> getAllTransactions() {
		return transactionsMap;
	}

	@Override
	public boolean addTransaction(Transactions tran,int transactId) {
		Transactions status = transactionsMap.put(transactId, tran);
		
	       if(status==null)
	    	   return true;
	       else
	    	   return false;
	}
	*/
}
