package src.com.capgemini.BankingSystem.Service;

import java.util.ArrayList;
import java.util.Collection;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import src.com.capgemin.BankingSystem.Bean.Banking;
import src.com.capgemin.BankingSystem.Bean.Transactions;
import src.com.capgemini.BankingSystem.Dao.BankinSystemDao;
import src.com.capgemini.BankingSystem.Exception.BankingException;

public class BankingSystemService implements IBankingService {

	int transactId = 0;
	double accountNo;

	src.com.capgemini.BankingSystem.Dao.IBankingSystemDao dao = new BankinSystemDao();

	static private double balance;

	@Override
	public int addTransact(Transactions tran, String acc) {
		transactId = (int) (Math.random() * 1000);
		tran.setTranscationId(transactId);
		boolean status = dao.insertToTransaction(tran, transactId);
		if (status)
			return transactId;

		return 0;

	}

	@Override
	public boolean addCustomer(Banking banking) {

		boolean status = dao.insertIntoBanking(banking);

		return status;

	}

	@Override
	public List<Transactions> printAllTransactions(String AccoutnNo) {
		List<Transactions> transactList = new ArrayList<>();
		transactList.addAll(dao.getAllTransaction(AccoutnNo));
		return transactList;
	}

	@Override
	public boolean narration(String string, double amount, String accountNo2) {

		if ((balance <=0 || balance-amount <= 0) && (string.equals("debit") || string.equals("transfer")))
			return false;
		else {

			switch (string) {
			case "debit":
				balance -= amount;
				break;
			case "credit":
				balance += amount;
				break;
			case "transfer":
				balance -= amount;
				break;
			}
			dao.updateBalance(balance, accountNo2);

			if (string.equals("debit") || string.equals("credit") || string.equals("transfer"))
				return true;
		}
		return false;
	}

	@Override
	public boolean isPhonevalid(String phone) throws BankingException {
		Pattern nameptn = Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher match = nameptn.matcher(phone);
		if (match.matches())
			return true;
		else
			return false;
	}

	@Override
	public boolean isNamevalid(String name) throws BankingException {
		Pattern nameptn = Pattern.compile("^[A-Z]*[a-z]*[//s]*$");
		Matcher match = nameptn.matcher(name);
		if (match.matches()) {
			return true;
		} else
			return false;
	}

	@Override
	public boolean isAadhaarvalid(String name) throws BankingException {
		Pattern nameptn = Pattern.compile("^[0-9 ]{12}$");
		Matcher match = nameptn.matcher(name);
		if (match.matches()) {
			return true;
		} else
			return false;
	}

	public int accountNo() {
		accountNo = (Math.random() * 1000);
		return (int) accountNo;
	}

	@Override
	public double balance(String accountNo) {
		balance = dao.balance(accountNo);
		return balance;

	}

	public Banking login(String user, String pass) {
		Banking bank = dao.loginUser(user, pass);
		return bank;

	}

}
