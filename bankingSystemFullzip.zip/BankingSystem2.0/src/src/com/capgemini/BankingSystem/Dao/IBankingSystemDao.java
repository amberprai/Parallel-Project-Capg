package src.com.capgemini.BankingSystem.Dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import src.com.capgemin.BankingSystem.Bean.Banking;
import src.com.capgemin.BankingSystem.Bean.Transactions;

public interface IBankingSystemDao {
	

	//boolean insertToTransaction(Transactions tran, int transactId, String AccountNo);
	boolean insertIntoBanking(Banking banking);
	List<Transactions> getAllTransaction(String AccountNo);
	void createTable(String accountNo);
	//void addtransfer(double balance, double amount, String account);
	Banking loginUser(String user, String pass);
	double balance(String accountNo);
	void updateBalance(double balance, String accountNo2);
	boolean insertToTransaction(Transactions tran, int transactId);
}
