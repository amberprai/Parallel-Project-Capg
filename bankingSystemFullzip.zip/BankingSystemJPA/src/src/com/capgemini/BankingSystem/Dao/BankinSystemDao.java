package src.com.capgemini.BankingSystem.Dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.persistence.*;
import src.com.capgemin.BankingSystem.Bean.Banking;
import src.com.capgemin.BankingSystem.Bean.Transactions;

public class BankinSystemDao implements IBankingSystemDao {
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager entityManager = factory.createEntityManager();
	int authorId = 0;
	static boolean status = false;
	List<Transactions> transList = null;

	@Override
	public void createTable(String accountNo) {
		/*
		 * try(Connection connection = DBConnection.getConnection();) {
		 * 
		 * //String query="create table "+accountNo+" (TId number(10) primary key,"
		 * +"Amount Number(10), "+"Balance Number(10),"+"Transaction_Date varchar2(20),"
		 * +"Narration varchar2(25))"; //System.out.println(query);
		 * statement=connection.prepareStatement("create table "
		 * +accountNo+" (TId number(10) primary key,"+"Amount Number(10), "
		 * +"Balance Number(10),"+"Transaction_Date varchar2(20),"
		 * +"Narration varchar2(25))"); status=statement.execute();
		 * System.out.println("Transaction Sheet Opened"); } catch (SQLException e) {
		 * System.out.println(e.getMessage()); }
		 */
	}

	@Override
	public boolean insertToTransaction(Transactions tran, int transactId) {

		/*
		 * statement =
		 * connection.prepareStatement("insert into transactions values(?,?,?,?,?,?,?)"
		 * ); System.out.println(tran.getTranscationId()); statement.setString(1,
		 * tran.getAccountNo()); statement.setInt(2, tran.getTranscationId());
		 * statement.setDouble(3, tran.getAmount()); statement.setDouble(4,
		 * tran.getBalance()); statement.setString(5, tran.getDate());
		 * statement.setString(6, tran.getNarration()); statement.setString(7,
		 * tran.getToAccountNo()); row = statement.executeUpdate();
		 */
		tran.setTranscationId(transactId);

		entityManager.getTransaction().begin();
		entityManager.persist(tran);
		entityManager.getTransaction().commit();

		return true;

	}

	@Override
	public boolean insertIntoBanking(Banking banking) {
		/*
		 * statement =
		 * connection.prepareStatement("select username from Banking where user=?");
		 * statement.setString(1,user); resultSet=statement.executeQuery();
		 * while(resultSet.next()) { if(resultSet.equals(user)) {
		 * System.out.println("User Already Exists"); return false; } }
		 */
		/*
		 * statement =
		 * connection.prepareStatement("insert into Banking values(?,?,?,?,?,?,?)");
		 * statement.setString(1, banking.getUsername()); statement.setString(2,
		 * banking.getPassword()); statement.setString(3, banking.getAccountNo());
		 * statement.setString(4, banking.getName()); statement.setString(5,
		 * banking.getAadhaar()); statement.setString(6, banking.getMobile());
		 * statement.setDouble(7, banking.getBalance());
		 * 
		 * row = statement.executeUpdate();
		 */
		entityManager.getTransaction().begin();
		entityManager.persist(banking);
		entityManager.getTransaction().commit();
		return true;
	}

	@Override
	public List<Transactions> getAllTransaction(String AccountNo) {
		transList = new ArrayList<>();
		/*
		 * try (Connection connection = DBConnection.getConnection();) { statement =
		 * connection.prepareStatement("select * from transactions where AccountNo ='" +
		 * AccountNo+"'"); System.out.println("select * from " + AccountNo); resultSet =
		 * statement.executeQuery(); while (resultSet.next()) { Transactions trans = new
		 * Transactions(); trans.setTranscationId(resultSet.getInt("TID"));
		 * trans.setAmount(resultSet.getDouble("Amount"));
		 * trans.setBalance(resultSet.getDouble("Balance"));
		 * trans.setDate(resultSet.getString("Transaction_Date"));
		 * trans.setNarration(resultSet.getString("Narration"));
		 * trans.setToAccountNo(resultSet.getString("ToAccountNO"));
		 * transList.add(trans); }
		 * 
		 * } catch (SQLException e) { System.out.println(e.getMessage()); }
		 * 
		 * 
		 */

		entityManager.getTransaction().begin();
		entityManager.clear();
		TypedQuery<Transactions> query = entityManager.createQuery("from transactions where AccountNo=?",
				Transactions.class);
		query.setParameter(1, AccountNo);
		transList = query.getResultList();
		entityManager.getTransaction().commit();
		return transList;
	}

	@Override
	public Banking loginUser(String user, String pass) {

		TypedQuery<Banking> query = entityManager.createQuery("from  Banking", Banking.class);
		List<Banking> bankList = query.getResultList();
		Iterator<Banking> iterator = bankList.iterator();
		Banking banking = null;
		while (iterator.hasNext()) {
			banking = iterator.next();

			if (banking.getUsername().contentEquals(user) && banking.getPassword().contentEquals(pass)) {
				Banking bank = new Banking();
				bank.setUsername(user);
				bank.setPassword(pass);
				bank.setAadhaar(banking.getAadhaar());
				bank.setAccountNo(banking.getAccountNo());
				bank.setMobile(banking.getMobile());
				bank.setName(banking.getName());
				bank.setBalance(banking.getBalance());
				return bank;
			}
		}
		return null;

	}

	@Override
	public double balance(String accountNo) {

		/*
		 * TypedQuery<Banking> query=entityManager.
		 * createQuery("select balance from  Banking where AccountNO ='" + accountNo +
		 * "'",Banking.class); double balance=query.getFirstResult();
		 */
		entityManager.getTransaction().begin();
		Banking banking = entityManager.find(Banking.class, accountNo);
		double balance = banking.getBalance();
		entityManager.getTransaction().commit();
		return balance;
	}

	@Override
	public void updateBalance(double balance, String accountNo) {
		entityManager.getTransaction().begin();
		TypedQuery<Banking> query = entityManager.createQuery(
				"update Banking  set balance= " + balance + "where AccountNO ='" + accountNo + "'", Banking.class);
		query.executeUpdate();
		entityManager.getTransaction().commit();

	}

	/*
	 * @Override public double getBalance(String accoutNo) {
	 * 
	 * try (Connection connection = DBConnection.getConnection();) { statement =
	 * connection.prepareStatement("select balance from"+AccountNo+" "); resultSet =
	 * statement.executeQuery(); while (resultSet.next()) if (resultSet.next()) {
	 * Transactions trans = new Transactions();
	 * trans.setTranscationId(resultSet.getInt("TID"));
	 * trans.setamount(resultSet.getDouble("Amount"));
	 * trans.setBalance(resultSet.getDouble("Balance"));
	 * trans.setDate(resultSet.getString("Date"));
	 * trans.setNarration(resultSet.getString("Narration")); transList.add(trans); }
	 * } catch (SQLException e) { System.out.println(e.getMessage()); }
	 * 
	 * return transList; }
	 * 
	 * 
	 */

	/*
	 * BankingRepository br=new BankingRepository(); Map<Integer, Transactions>
	 * transactionsMap = new LinkedHashMap<Integer, Transactions>(); public
	 * BankinSystemDao() { transactionsMap.putAll(br.getTransList()); }
	 * 
	 * 
	 * int id=0;
	 * 
	 * @Override public Map<Integer, Transactions> getAllTransactions() { return
	 * transactionsMap; }
	 * 
	 * @Override public boolean addTransaction(Transactions tran,int transactId) {
	 * Transactions status = transactionsMap.put(transactId, tran);
	 * 
	 * if(status==null) return true; else return false; }
	 */
}
