package src.com.capgemin.BankingSystem.Bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Transactions")
public class Transactions {
	private double amount;
	private double balance;
	private String date;
	private String narration;
	@Id
	private int transcationId;
	private String accountNo;
	private String toAccountNo;

	public Transactions() {
		super();
	}

	
	public Transactions( int transcationId,double amount, double balance, String date, String narration,
			String accountNo, String toAccountNo) {
		super();
		this.amount = amount;
		this.balance = balance;
		this.date = date;
		this.narration = narration;
		this.transcationId = transcationId;
		this.accountNo = accountNo;
		this.toAccountNo = toAccountNo;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getNarration() {
		return narration;
	}

	public void setNarration(String narration) {
		this.narration = narration;
	}

	public int getTranscationId() {
		return transcationId;
	}

	public void setTranscationId(int transcationId) {
		this.transcationId = transcationId;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getToAccountNo() {
		return toAccountNo;
	}

	public void setToAccountNo(String toAccountNo) {
		this.toAccountNo = toAccountNo;
	}


	@Override
	public String toString() {
		return " "+date+"\t\t  "+transcationId+"\t\t  "+balance+"\t\t  "+amount+"\t\t  "+ narration+"\t\t  "+toAccountNo ;
	}
	
	

}
