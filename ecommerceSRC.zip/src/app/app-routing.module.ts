import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrderHistoryComponent } from './order/frontend/order-history/order-history.component';
import { OrderDetailComponent } from './order/frontend/order-detail/order-detail.component';
import { ShoppingCartComponent } from './order/frontend/shopping-cart/shopping-cart.component';
import { CartCheckoutComponent } from './order/frontend/cart-checkout/cart-checkout.component';


const routes: Routes = [
  {path:'',component:OrderHistoryComponent},
  {path:'orderList',component:OrderHistoryComponent},
  {path:'orderDetail',component:OrderDetailComponent},
  {path:'shoppingCart',component:ShoppingCartComponent},
  {path:'cartCheckout',component:CartCheckoutComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
