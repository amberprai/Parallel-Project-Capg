import { OrderDetail } from './order-detail';

describe('OrderDetail', () => {
  it('should create an instance', () => {
    expect(new OrderDetail()).toBeTruthy();
  });
});
