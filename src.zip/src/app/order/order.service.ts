import { Injectable } from '@angular/core';
import { OrderDetail } from '../order-detail';

import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class OrderServiceService {
  url:string="http://localhost:5050/orders";
  orders:OrderDetail[];
  order:OrderDetail;
  set: any;

  constructor(private http:HttpClient) {
    this.getOrder().subscribe(data=>this.orders=data);
   }
   getOrder():Observable<OrderDetail[]> {
    return this.http.get<OrderDetail[]>(this.url);
  }

  getData(){
    return this.orders;
  }

  setOrder(orders:OrderDetail[])
  {
    this.orders=orders;
  }

   
}
