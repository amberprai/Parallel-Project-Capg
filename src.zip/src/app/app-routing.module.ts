import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrderHistoryComponent } from './order/order-history/order-history.component';
import { OrderDetailComponent } from './order/order-detail/order-detail.component';


const routes: Routes = [
  {path:'',component:OrderHistoryComponent},
  {path:'orderList',component:OrderHistoryComponent},
  {path:'orderDetail',component:OrderDetailComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
