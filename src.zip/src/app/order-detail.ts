export class OrderDetail {
    orderId :number;
    quantity:number;
    totalAmount:number;
    orderDate:any;
    status:string;
}
