package com.cg.emp.service;

import java.util.List;

import com.cg.emp.dto.Employee;
import com.cg.emp.exceptions.EmployeeException;

public interface EmployeeService {
	 List<Employee> getAllEmployees() throws EmployeeException ;

	List<Employee> deleteEmployee(int id) throws EmployeeException;
	List<Employee> addEmployee(Employee employee) throws EmployeeException;
}
