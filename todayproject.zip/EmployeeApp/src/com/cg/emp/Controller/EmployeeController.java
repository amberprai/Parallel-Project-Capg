package com.cg.emp.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.emp.dto.Employee;
import com.cg.emp.exceptions.EmployeeException;
import com.cg.emp.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	EmployeeService employeeSerivce;

	@RequestMapping("/greet")
	public String sayHello() {
		return "greet";
	}

	@RequestMapping("/")
	public ModelAndView showIndex() {
		try {
			List<Employee> employees = employeeSerivce.getAllEmployees();
			ModelAndView mv = new ModelAndView("index");
			mv.addObject("employees", employees);
			return mv;
		} catch (EmployeeException e) {
			ModelAndView mv = new ModelAndView("error");
			mv.addObject("error", e);
			return mv;
		}
	}

	@RequestMapping("/delete")
	public ModelAndView deleteEmployee(@RequestParam int id) {
		try {
			List<Employee> employees = employeeSerivce.deleteEmployee(id);
			ModelAndView mv = new ModelAndView("index");
			mv.addObject("employees", employees);
			return mv;
		} catch (EmployeeException e) {
			ModelAndView mv = new ModelAndView("error");
			mv.addObject("error", e);
			return mv;
		}

	}

	@RequestMapping("/addEmployee")
	public String showAddForm(Model model) {
		model.addAttribute("employee", new Employee());
		return "add"; // it will view add.jsp
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public ModelAndView addEmployee(@Valid @ModelAttribute Employee employee,
			BindingResult result/* to contain error mesaage */) {

		if (result.hasErrors()) {
			/**
			 * ModelAndView mv=new ModelandView("index"); mv.addObject("employee",employee);
			 * return mv;
			 */
			return new ModelAndView("add", "employee", employee);
		}

		try {
			List<Employee> employees = employeeSerivce.addEmployee(employee);
			ModelAndView mv = new ModelAndView("index");
			mv.addObject("employees", employees);
			return mv;
		} catch (EmployeeException e) {
			ModelAndView mv = new ModelAndView("error");
			mv.addObject("error", e);
			return mv;
		}

	}
}
