/*package src.com.capgemin.BankingSystemJUnitTest;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import src.com.capgemin.BankingSystem.Bean.Transactions;
import src.com.capgemini.BankingSystem.Service.BankingSystemService;

class BankingServiceTest {
	Transactions transactions =null;
	BankingSystemService service=new BankingSystemService();
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testaddTransaction() {
		transactions= new Transactions(0,1000,2000,"20-01-19","Debit");
		int num=service.addTransact(transactions);
		assertNotNull(num);
		assertNotSame(num, 114);
	
	}
	
	@Test
	void testprintAllTransactions() {
		assertNotNull(service.printAllTransactions());
		assertNotEquals(service.printAllTransactions(), 100);
		
	}
	
	
	@Test	
	void testnarration()
	{
		boolean result=service.narration("debit", 2000);
		assertTrue(result);
		boolean result1=service.narration("hello", 2000);
		assertFalse(result1);
		
	}
	
	@Test
	void isPhonevalid() {
		try {
			boolean result=service.isPhonevalid("9515766055");
			assertTrue(result);
			boolean result1=service.isPhonevalid("95166055");
			assertFalse(result1);
		} catch (BankingException e) {
			
			e.printStackTrace();
		}
		
		
	}
	@Test
	void isNameValid() {
		try {
			boolean result=service.isNamevalid("Amber");
			assertTrue(result);
			boolean result1=service.isNamevalid("amber");
			assertFalse((result1));
		} catch (BankingException e) {
			e.printStackTrace();
		}
		
		
	}
	@Test
	void isAadhaarvalid() throws BankingException{
		try {
			boolean result=service.isAadhaarvalid("123412341234");
			assertTrue(result);
			boolean result1=service.isNamevalid("12341234");
			assertFalse(result1);
			
		} catch (BankingException e) {
			e.printStackTrace();
		}
		
		
	}
	@Test
	void accountNo() {
		assertNotNull(service.accountNo());
		assertNotEquals(service.accountNo(), 12345);
		
	}
	
	@Test
	void balance() {
		assertNotEquals(service.balance(),200);
		assertEquals(service.balance(),2000);
		assertNotNull(service.balance());
	}

}*/
