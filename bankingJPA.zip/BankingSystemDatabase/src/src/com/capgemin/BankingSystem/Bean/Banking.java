package src.com.capgemin.BankingSystem.Bean;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Banking {
	@Id
	@Column(name="AccountNo")
	@OneToMany(cascade = CascadeType.ALL)
	private String accountNo;
	@Column(name="Username")
	private String username;
	@Column(name="Password")
	private String password;
	@Column(name="Name")
	private String name;
	@Column(name="Mobile")
	private String mobile;
	@Column(name="Aadhaar")
	private String Aadhaar;
	@Column(name="balance")
	private double balance;

	public Banking() {
		super();
	}
	

	public Banking(String accountNo, String username, String password, String name, String mobile,String aadhaar,double balance) {
		super();
		this.accountNo = accountNo;
		this.username = username;
		this.password = password;
		this.name = name;
		this.mobile = mobile;
		this.balance = balance;
		Aadhaar = aadhaar;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getAadhaar() {
		return Aadhaar;
	}

	public void setAadhaar(String aadhaar) {
		Aadhaar = aadhaar;
	}

	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return "Banking [accountNo=" + accountNo + ", username=" + username + ", password=" + password + ", name="
				+ name + ", mobile=" + mobile + ", balance=" + balance + ", Aadhaar=" + Aadhaar + "]";
	}

}
