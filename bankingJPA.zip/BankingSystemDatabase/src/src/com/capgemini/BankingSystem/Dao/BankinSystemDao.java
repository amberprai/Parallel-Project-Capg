package src.com.capgemini.BankingSystem.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import src.com.capgemin.BankingSystem.Bean.Banking;
import src.com.capgemin.BankingSystem.Bean.Transactions;

public class BankinSystemDao implements IBankingSystemDao {
	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;
	int row = -1;
	int authorId = 0;
	static boolean status = false;
	List<Transactions> transList = null;
	

	static EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	static EntityManager em = factory.createEntityManager();

	@Override
	public void createTable(Banking banking) {
		em.getTransaction().begin();
		em.persist(banking.getAccountNo());
		em.getTransaction().commit();
	}

	@Override
	public boolean insertToTransaction(Transactions tran, int transactId, String AccountNo) {
		TypedQuery<Transactions> query = em.createQuery("insert into " + AccountNo + " values(?,?,?,?,?)",
				Transactions.class);
		query.setParameter(1, transactId);
		query.setParameter(2, tran.getamount());
		query.setParameter(3, tran.getBalance());
		query.setParameter(4, tran.getDate());
		query.setParameter(5, tran.getNarration());
		return true;
	}

	@Override
	public boolean insertIntoBanking(Banking banking) {
		TypedQuery<Banking> query = em.createQuery("insert into Banking values(?,?,?,?,?,?,?)", Banking.class);
		query.setParameter(1, banking.getUsername());
		query.setParameter(2, banking.getPassword());
		query.setParameter(3, banking.getAadhaar());
		query.setParameter(4, banking.getAccountNo());
		query.setParameter(5, banking.getMobile());
		query.setParameter(6, banking.getName());
		query.setParameter(7, banking.getBalance());
		return true;

	}

	@Override
	public List<Transactions> getAllTransaction(String AccountNo) {
		transList = new ArrayList<>();
		em.getTransaction().begin();
		em.clear();
		TypedQuery<Transactions> query = em.createQuery("from "+AccountNo+"", Transactions.class);
		transList = query.getResultList();
		em.getTransaction().commit();
		//query.setParameter(1, AccountNo);
		
		return transList;
	}

	@Override
	public Banking loginUser(String user, String pass) {
		TypedQuery<Banking> query = em.createQuery("from  Banking", Banking.class);
		List<Banking> bankList = query.getResultList();

		for (Banking bank : bankList) {
			if (bank.getUsername().equals(user) && bank.getPassword().equals(pass))
				return bank;

		}
		return null;
	}

	@Override
	public double balance(String accountNo) {
	TypedQuery<Banking> query=em.createQuery("select  balance from  Banking where AccountNO =" + accountNo + "'",Banking.class);
	double balance=query.getFirstResult();
	
	return balance;
	}

	@Override
	public void updateBalance(double balance, String accountNo) {
		TypedQuery<Banking> query=em.createQuery("update Banking  set balance= " + balance + "where AccountNO ='" + accountNo + "'",Banking.class);
		
	}

	/*
	 * @Override public double getBalance(String accoutNo) {
	 * 
	 * try (Connection connection = DBConnection.getConnection();) { statement =
	 * connection.prepareStatement("select balance from"+AccountNo+" "); resultSet =
	 * statement.executeQuery(); while (resultSet.next()) if (resultSet.next()) {
	 * Transactions trans = new Transactions();
	 * trans.setTranscationId(resultSet.getInt("TID"));
	 * trans.setamount(resultSet.getDouble("Amount"));
	 * trans.setBalance(resultSet.getDouble("Balance"));
	 * trans.setDate(resultSet.getString("Date"));
	 * trans.setNarration(resultSet.getString("Narration")); transList.add(trans); }
	 * } catch (SQLException e) { System.out.println(e.getMessage()); }
	 * 
	 * return transList; }
	 * 
	 * 
	 */

	/*
	 * BankingRepository br=new BankingRepository(); Map<Integer, Transactions>
	 * transactionsMap = new LinkedHashMap<Integer, Transactions>(); public
	 * BankinSystemDao() { transactionsMap.putAll(br.getTransList()); }
	 * 
	 * 
	 * int id=0;
	 * 
	 * @Override public Map<Integer, Transactions> getAllTransactions() { return
	 * transactionsMap; }
	 * 
	 * @Override public boolean addTransaction(Transactions tran,int transactId) {
	 * Transactions status = transactionsMap.put(transactId, tran);
	 * 
	 * if(status==null) return true; else return false; }
	 */
}
