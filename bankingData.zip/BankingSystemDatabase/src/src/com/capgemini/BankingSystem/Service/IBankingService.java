package src.com.capgemini.BankingSystem.Service;

import java.util.List;

import src.com.capgemin.BankingSystem.Bean.Banking;
import src.com.capgemin.BankingSystem.Bean.Transactions;
import src.com.capgemini.BankingSystem.Exception.BankingException;

public interface IBankingService {
	public int accountNo();
	

	
	public boolean isPhonevalid(String phone)throws BankingException;
	public boolean isNamevalid(String name)throws BankingException;
	boolean isAadhaarvalid(String name) throws BankingException;
	int addTransact(Transactions tran, String acc);
	List<Transactions> printAllTransactions(String AccoutnNo);
	boolean addCustomer(Banking banking);
	double balance(String accountNo);



	boolean narration(String string, double amount, String accountNo2);
   
}
