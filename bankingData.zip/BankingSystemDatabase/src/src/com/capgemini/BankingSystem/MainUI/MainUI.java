package src.com.capgemini.BankingSystem.MainUI;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import src.com.capgemin.BankingSystem.Bean.Banking;
import src.com.capgemin.BankingSystem.Bean.Transactions;
import src.com.capgemini.BankingSystem.Exception.BankingException;
import src.com.capgemini.BankingSystem.Service.BankingSystemService;

public class MainUI {
	static Scanner scanner = null;
	static String name;
	static String mobile;
	static String aadharNo;
	static String accountNo;
	static String choices;
	static double balance;
	static int flow = 0;
	static MainUI obj = new MainUI();
	static BankingSystemService service = new BankingSystemService();
	private double amount;
	boolean result;
	private int transact;
	private int AccountFlag = 0;
	static int welcomeFlag = 0;
	static int choice = 0;
	static boolean bool = true;
	private static int LoginFlag;

	public static void main(String[] args) {

		System.out.println("******************| Welcome to CapGemini NetBanking |****************** ");
		do {
			System.out.println(" 1. Create Account \t\t\t 2. Log In");
			scanner = new Scanner(System.in);
			int ch = scanner.nextInt();
			if (ch == 1)
				obj.createAccount();
			else if (ch == 2) {
				scanner = new Scanner(System.in);

				System.out.println("\nPlease Login");
				System.out.print("Username:");
				String user = scanner.nextLine();
				System.out.print("Password :");
				String pass = scanner.nextLine();

				Banking bank = service.login(user, pass);
				if (bank == null) {
					System.err.println("Invalid Username/Password or User doesnot exists");
					LoginFlag = 0;
				} else {
					System.err.println("\t User Authenticated");
					name = bank.getName();
					mobile = bank.getMobile();
					aadharNo = bank.getAadhaar();
					accountNo = bank.getAccountNo();
					balance = bank.getBalance();
					try {
						usermenu();
					}
					catch(InputMismatchException | BankingException e)
					{
						System.err.println("Please Enter Valid Input");
					}
					LoginFlag = 1;

				}
			}

		} while (LoginFlag == 0);

		/*
		 * if (user.equals(username) && password.equals(pass)) {
		 * 
		 * welcomeFlag = 1; } else System.err.println("InCorrect Username or Password");
		 * } while (!user.equals(username) && !password.equals(pass));
		 */

	}

	private static void usermenu() throws BankingException {
		System.out.println("******************| Welcome " + name + " to CapGemini NetBanking |******************");
			do {
			System.out.println("\n \t \t      .. Pool Menu ..");
			
			do {
				System.out.println("\n 1.Account Balance  \t\t\t 2.Deposit ");
				System.out.println("3. Withdraw		   \t\t 4.Transfer");
				System.out.println("5. Account Statement  \t\t\t 6. Exit");
				System.out.print("\n Whats your choice ? ");
				scanner = new Scanner(System.in);
				choice = scanner.nextInt();
				switch (choice) {
				case 1:
					obj.showBalance();
					break;
				case 2:obj.deposit();
				break;
						

				case 3:obj.withdraw();
				break;
						

				case 4:obj.transfer();
				break;
						
				case 5:obj.printTransactions();
				break;
						

				case 6:System.err.println(" " + name + " !! Your session has been Logged Out from Capgemini");
				System.exit(0);			

				default:
					System.err.println("Please enter options between 1-6..");
				}

			
				System.out.println("\nDo you wish to Continue ? (Y= yes/N= no)");
				scanner = new Scanner(System.in);
				choices = scanner.nextLine();
				if (choices.equalsIgnoreCase("y") || choices.equalsIgnoreCase("n"))
					bool = false;
				else {
					System.err.println("Invalid Input!! Enter Y or N");
					bool = true;
				}
			} while (bool);
			if (choices.equalsIgnoreCase("n"))
				System.err.println(" " + name + " !! Your session has been Logged Out from Capgemini");
			
		} while (choices.equalsIgnoreCase("y"));
			
			

		
	}

	private void printTransactions() {
		List<Transactions> list = new ArrayList<>();
		list = service.printAllTransactions(accountNo);

		System.out.println(
				"************************************ CapGemini NetBanking ****************************************");
		System.out.println("\n-> Account/ Account Statement");
		System.out.println(
				"\n--------------------------------------------------------------------------------------------------");
		System.out.println("Account Number : " + accountNo);
		System.out.println("Account Name   : " + name);
		System.out.println("Account Mobile : " + mobile);
		System.out.println("Account Aadhar : " + aadharNo);
		System.out.println("Account Type   : Savings Bank");
		System.out.println(
				"----------------------------------------------------------------------------------------------------\n");

		System.out.println("    Date \t  Transacton Id \t Balance \t    Amount \t    Narration ");
		System.out.println(
				"__________________________________________________________________________________________________");
		Iterator<Transactions> iterator = list.iterator();
		while (iterator.hasNext())
			System.out.println(iterator.next());
		System.out.println(
				"\n**************************************************************************************************");

	}

	private void transfer() {
		scanner = new Scanner(System.in);
		System.out.println("-> Account/ Transfer");
		System.out.println("--------------------");
		System.out.println("Transferring ->");
		System.out.print(" Account No : ");
		String recieverAccountNo = scanner.nextLine();
		try {
			System.out.print(" Amount :");
			amount = scanner.nextDouble();
		} catch (InputMismatchException e) {
			System.out.println("Please Enter Valid Amount");
		}

		result = service.narration("debit", amount,accountNo);
		balance = service.balance(accountNo);
		String transfer = "Tranfer to " + recieverAccountNo;

		Transactions trans = new Transactions(0, amount, balance, LocalDate.now().toString(), transfer);
		transact = service.addTransact(trans, accountNo);

		service.narration("credit", amount,recieverAccountNo);
		Transactions transferobj = new Transactions(0, amount, balance, LocalDate.now().toString(),
				"Credit || Transfer from " + accountNo);
		service.addTransact(transferobj, recieverAccountNo);

		System.out.print("Transaction successful. Your Transaction No. ");
		System.err.print(transact);
		System.out.println(" !! Save it for future reference.");
	}

	private void withdraw() {
		scanner = new Scanner(System.in);
		System.out.println("-> Account/ Withdraw");
		System.out.println("--------------------");
		System.out.println("Withdrawing ->  \n  ");
		try {
			System.out.print(" Amount :");
			amount = scanner.nextDouble();
		} catch (InputMismatchException e) {
			System.out.println("Please Enter Valid Amount");
		}
		result = service.narration("debit", amount,accountNo);
		balance = service.balance(accountNo);

		Transactions trans = new Transactions(0, amount, balance, LocalDate.now().toString(), "Debit");

		transact = service.addTransact(trans, accountNo);
		

		System.out.print("Transaction successful. Your Transaction No. ");
		System.err.print(transact);
		System.out.println(" !! Save it for future reference.");
	}

	private void deposit() {
		scanner = new Scanner(System.in);
		System.out.println("-> Account/ Deposit");
		System.out.println("--------------------");
		System.out.println(" Depositing ->  \n");
		try {
			System.out.print(" Amount :");
			amount = scanner.nextDouble();
		} catch (InputMismatchException e) {
			System.out.println("Please Enter Valid Amount");
		}
		result = service.narration("credit", amount,accountNo);
		balance = service.balance(accountNo);

		Transactions trans = new Transactions(0, amount, balance, LocalDate.now().toString(), "Credit");

		transact = service.addTransact(trans, accountNo);

		System.out.print("Transaction successful. Your Transaction No. ");
		System.err.print(transact);
		System.out.println(" !! Save it for future reference.");
	}

	private void showBalance() {
		System.out.println("-> Account/ Account Balance");
		System.out.println("----------------------------");
		System.out.println("\nAccount Number : " + accountNo);
		System.out.println("Account Name   : " + name);
		System.out.println("Account Mobile : " + mobile);
		System.out.println("Account Aadhar : " + aadharNo);
		System.out.println("Account Type   : Savings Bank");
		balance = service.balance(accountNo);
		System.out.print("Balance Available as on " + LocalDate.now() + " : ");
		System.err.println(balance);
		System.out.println();
	}

	private void createAccount() {
		if (AccountFlag != 1) {
			AccountFlag = 1;

			String user, pass;
			System.out.println("Registration of New User || Fill In KYC Details ");
			try {
				do {
					System.out.print("Full Name: ");
					scanner = new Scanner(System.in);
					name = scanner.nextLine();

					if (service.isNamevalid(name)) {
						do {
							System.out.print("Mobile :");
							mobile = scanner.nextLine();
							if (service.isPhonevalid(mobile)) {
								do {
									System.out.print("Aadhaar No :");
									aadharNo = scanner.next();
									if (service.isAadhaarvalid(aadharNo)) {
										scanner = new Scanner(System.in);
										System.out.print("Choose Username :");
										String username = scanner.nextLine();
										System.out.print("Choose Password :");
										String password = scanner.nextLine();

										int accountNo1 = service.accountNo();

										accountNo = "CAPG" + accountNo1;
										System.out.println("Account Created..!! Account No: " + accountNo);
										Banking banking = new Banking(accountNo, username, password, name, mobile,
												aadharNo, 2000);
										service.addCustomer(banking);
										scanner = new Scanner(System.in);
										System.out.println("____________________________________________________\n");
									}

									else {
										try {
											throw new BankingException(
													"Invalid Aadhar Number.(Must be a 12 digit number)");
										} catch (BankingException e) {
											System.err.println(e.getMessage());
										}

									}
								} while (!service.isAadhaarvalid(aadharNo));
							} else
								try {
									throw new BankingException(
											"Invalid Mobile Number(Must have 10 digit and start with 6,7,8 or 9)");
								} catch (BankingException e) {
									System.err.println(e.getMessage());
								}
						} while (!service.isPhonevalid(mobile));
					} else
						try {
							throw new BankingException("Invalid Name(First letter Must be Capital)");
						} catch (BankingException e) {
							System.err.println(e.getMessage());
						}
				} while (!service.isNamevalid(name));

			} catch (BankingException e) {
				e.printStackTrace();
			}
		} else
			System.err.println("Account has been already created");

	}
}
