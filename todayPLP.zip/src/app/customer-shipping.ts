export class CustomerShipping {
    id:number;
    status:string;
    date:string;
    quantity:number;
    amount:number;
    name:string;
    phone:string;
    shipping:string;
}