import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OrderDetailComponent } from './order/frontend/order-detail/order-detail.component';
import { OrderHistoryComponent } from './order/frontend/order-history/order-history.component';
import { CartCheckoutComponent } from './order/frontend/cart-checkout/cart-checkout.component';
import { ShoppingCartComponent } from './order/frontend/shopping-cart/shopping-cart.component';
import { HttpClientModule } from '@angular/common/http';
import { OrderServiceService } from './order/order.service';
import { OrderlistingComponent } from './order/backend/orderlisting/orderlisting.component';
import { OrderdetailsComponent } from './order/backend/orderdetails/orderdetails.component';
import { EditorderComponent } from './order/backend/editorder/editorder.component';
@NgModule({
  declarations: [
    AppComponent,
    OrderDetailComponent,
    OrderHistoryComponent,
    CartCheckoutComponent,
    ShoppingCartComponent,
    OrderlistingComponent,
    OrderdetailsComponent,
    EditorderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule,FormsModule
  ],
  providers: [OrderServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
