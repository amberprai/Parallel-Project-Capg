export class Adminorder {
    orderId:number;
    name:string;
    noOfCopies:number;
    total:number;
    payment:string;
    status:string;
    order:string;
    
}
