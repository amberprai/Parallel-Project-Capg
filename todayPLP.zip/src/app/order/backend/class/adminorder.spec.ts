import { Adminorder } from './adminorder';

describe('Adminorder', () => {
  it('should create an instance', () => {
    expect(new Adminorder()).toBeTruthy();
  });
});
