import { Component, OnInit } from '@angular/core';
import{Adminorder} from 'src/app/order/backend/class/adminorder'
import { AdminService } from '../service/admin.service';
@Component({
  selector: 'app-orderlisting',
  templateUrl: './orderlisting.component.html',
  styleUrls: ['./orderlisting.component.css']
})
export class OrderlistingComponent implements OnInit {
orders:Adminorder;
  constructor(private adminOrderService:AdminService) { }
  

  ngOnInit() {
  }
  

}
