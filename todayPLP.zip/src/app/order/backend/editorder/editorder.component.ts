import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editorder',
  templateUrl: './editorder.component.html',
  styleUrls: ['./editorder.component.css']
})
export class EditorderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
