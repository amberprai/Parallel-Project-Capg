import { Component, OnInit } from '@angular/core';
import { OrderServiceService } from 'src/app/order/order.service';
import { Orderhistory } from 'src/app/orderhistory';
import { CustomerShipping } from 'src/app/customer-shipping';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order-detail',
  templateUrl: './order-detail.component.html',
  styleUrls: ['./order-detail.component.css']
})
export class OrderDetailComponent implements OnInit {
 bookDetails:Orderhistory[];
 book:Orderhistory;
 customerDetail:CustomerShipping[];

  constructor(private orderService:OrderServiceService,private router:Router) { }

  ngOnInit() {
    if(!this.orderService.getBookData()){
      this.orderService.getBook().subscribe(data=>{
        this.bookDetails=data;
        this.orderService.setBook(this.bookDetails);
       
   console.log(this.book.price);
    this.book.subtotal=this.book.price*this.book.quantity;
  
    this.orderService.createOrder(this.book).subscribe(data=>this.router.navigate(['orderDetail']));
      });

      if(!this.orderService.getCustomerData()){
        this.orderService.getCustomer().subscribe(data=>{
          this.customerDetail=data;
          this.orderService.setCustomer(this.customerDetail);
        });

    }
    
    
  }
}
}
