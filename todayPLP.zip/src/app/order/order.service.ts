import { Injectable } from '@angular/core';
import { OrderDetail } from '../order-detail'
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Orderhistory, ShoppingCart } from '../orderhistory';
import { CustomerShipping } from '../customer-shipping';


@Injectable({
  providedIn: 'root'
})
export class OrderServiceService {
  url1:string="http://localhost:5000/orders";
  url2:string="http://localhost:5000/bookDetail";
  url3:string="http://localhost:5000/customerShipping";
  url4:string="http://localhost:5000/shoppingCart";
  orders:OrderDetail[];
  order:OrderDetail;
  bookDetails:Orderhistory[];
  book:Orderhistory;
  customerShipping:CustomerShipping[];
  shoppingCart:ShoppingCart[];

  set: any;

  constructor(private http:HttpClient) {
    this.getOrder().subscribe(data=>this.orders=data);
    this.getBook().subscribe(data=>this.bookDetails=data);
    this.getCustomer().subscribe(data=>this.customerShipping=data);
    this.getCartDetails().subscribe(data=>this.shoppingCart=data);
   }
   getOrder():Observable<OrderDetail[]> {
    return this.http.get<OrderDetail[]>(this.url1);
  }
  getBook():Observable<Orderhistory[]> {
    return this.http.get<Orderhistory[]>(this.url2);
  }
  getCustomer():Observable<CustomerShipping[]> {
    return this.http.get<CustomerShipping[]>(this.url3);
  }

  getCartDetails():Observable<ShoppingCart[]> {
    return this.http.get<ShoppingCart[]>(this.url4);
  }

  getData(){
    return this.orders;
  }
  getBookData(){
    return this.bookDetails;
  }
  getCustomerData(){
    return this.customerShipping;
  }
  getCartData(){
    return this.shoppingCart;
  }

  setOrder(orders:OrderDetail[])
  {
    this.orders=orders;
  }
  setBook(bookDetails:Orderhistory[])
  {
    this.bookDetails=bookDetails;
  }
  setSubtotal(book:Orderhistory)
  {
    this.book=book;
  }
  setCustomer(customerShipping:CustomerShipping[])
  {
    this.customerShipping=customerShipping;
  }
  setCartData(shoppingCart:ShoppingCart[])
  {
    this.shoppingCart=shoppingCart;
  }
  createOrder(order:Orderhistory){
    console.log(order);
    return this.http.post(this.url4,order);   
}
}
